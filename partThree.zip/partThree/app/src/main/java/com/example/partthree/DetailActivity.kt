package com.example.partthree

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import com.airbnb.lottie.LottieAnimationView

class DetailActivity : AppCompatActivity() {
    private lateinit var exerciseNameTV: TextView
    private lateinit var caloriesTV: TextView
    private lateinit var timeTV: TextView
    private lateinit var descTV: TextView
    private lateinit var exerciseLAV: LottieAnimationView
    private lateinit var exerciseName: String
    private lateinit var desc: String
    private lateinit var imgUrl: String
    private var calories: Int = 0
    private var time: Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)
        exerciseNameTV = findViewById(R.id.idTVExerciseName)
        caloriesTV = findViewById(R.id.idTVCalories)
        timeTV = findViewById(R.id.idTVTime)
        descTV = findViewById(R.id.idTVDescription)
        exerciseLAV = findViewById(R.id.idExerciseLAV)

        exerciseName = intent.getStringExtra("exerciseName")!!
        desc = intent.getStringExtra("desc")!!
        imgUrl = intent.getStringExtra("imgUrl")!!
        calories = intent.getIntExtra("calories", 0)
        time = intent.getIntExtra("time", 0)

        exerciseNameTV.text = exerciseName
        caloriesTV.text = "Calories : $calories"
        timeTV.text = "Time : $time"
        descTV.text = desc
        exerciseLAV.setAnimationFromUrl(imgUrl)
    }
}
