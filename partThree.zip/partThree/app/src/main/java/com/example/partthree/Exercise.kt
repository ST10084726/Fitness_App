package com.example.partthree

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class Exercise : AppCompatActivity(), ExerciseRVAdapter.ExerciseClickInterface {
    private lateinit var exerciseRV: RecyclerView
    private lateinit var exerciseRVModelArrayList: ArrayList<ExerciseRVModel>
    private lateinit var exerciseRVAdapter: ExerciseRVAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_exercise)
        exerciseRV = findViewById(R.id.idRVExercise)
        exerciseRVModelArrayList = ArrayList()
        exerciseRVAdapter = ExerciseRVAdapter(exerciseRVModelArrayList, this, this)
        val manager = LinearLayoutManager(this)
        exerciseRV.layoutManager = manager
        exerciseRV.adapter = exerciseRVAdapter
        addData()
    }

    private fun addData() {
        exerciseRVModelArrayList.add(ExerciseRVModel("Side Plank", resources.getString(R.string.side_plank), "https://assets4.lottiefiles.com/packages/lf20_EOXjkv.json", 20, 10))
        exerciseRVModelArrayList.add(ExerciseRVModel("Lunges", resources.getString(R.string.lunges), "https://assets4.lottiefiles.com/packages/lf20_XbVCR4.json", 30, 10))
        exerciseRVModelArrayList.add(ExerciseRVModel("High Stepping", resources.getString(R.string.stepping), "https://assets4.lottiefiles.com/packages/lf20_igizh2.json", 40, 10))
        exerciseRVModelArrayList.add(ExerciseRVModel("Abs Crunches", resources.getString(R.string.abs_crunches), "https://assets4.lottiefiles.com/packages/lf20_Ajcy3F.json", 30, 20))
        exerciseRVModelArrayList.add(ExerciseRVModel("Push Ups", resources.getString(R.string.push_ups), "https://assets4.lottiefiles.com/packages/lf20_cswADz.json", 30, 5))
        exerciseRVAdapter.notifyDataSetChanged()
    }

    override fun onExerciseClick(position: Int) {
        val i = Intent(this, DetailActivity::class.java)
        i.putExtra("exerciseName", exerciseRVModelArrayList[position].exerciseName)
        i.putExtra("imgUrl", exerciseRVModelArrayList[position].imgUrl)
        i.putExtra("time", exerciseRVModelArrayList[position].time)
        i.putExtra("calories", exerciseRVModelArrayList[position].calories)
        i.putExtra("desc", exerciseRVModelArrayList[position].exerciseDescription)
        startActivity(i)
    }
}
