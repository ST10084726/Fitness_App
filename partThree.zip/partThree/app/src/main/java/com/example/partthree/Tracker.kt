package com.example.partthree

import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.view.View
import android.widget.Button
import android.widget.TextView
import com.github.mikephil.charting.charts.LineChart
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.data.LineData
import com.github.mikephil.charting.data.LineDataSet
import java.util.*

class Tracker : AppCompatActivity() {
    //variables
    private lateinit var tvTime: TextView
    private lateinit var tvLapTime: TextView
    private lateinit var btnStartStop: Button
    private lateinit var btnReset: Button
    private lateinit var btnLap: Button
    private lateinit var chart: LineChart
    private var lapNumber = 1
    private val lapTimes = mutableListOf<Long>()
    private lateinit var handler: Handler
    private lateinit var runnable: Runnable
    private var isRunning = false
    private var startTime: Long = 0
    private var elapsedTime: Long = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tracker)
        tvTime = findViewById(R.id.tvTime)
        tvLapTime = findViewById(R.id.tvlapTime)
        btnStartStop = findViewById(R.id.btnstartStop)
        btnReset = findViewById(R.id.btnReset)
        btnLap = findViewById(R.id.btnLap)
        chart = findViewById(R.id.chart)

// Set up the chart properties
        chart.description.isEnabled = true
        chart.setDrawGridBackground(true)
        chart.axisLeft.isEnabled = true
        chart.axisRight.isEnabled = true
        chart.xAxis.position = XAxis.XAxisPosition.BOTTOM

        handler = Handler()
        runnable = Runnable {
            elapsedTime = System.currentTimeMillis() - startTime
            tvTime.text = formatTime(elapsedTime)
            handler.postDelayed(this@Tracker.runnable, 100)
        }

    }

    fun startStopWatch(view: View) {
        if (!isRunning) {
            isRunning = true
            startTime = System.currentTimeMillis()
            handler.postDelayed(runnable, 0)
            btnStartStop.text = "STOP"
            lapNumber = 1
            lapTimes.clear()
            tvLapTime.text = ""
        } else {
            stopStopWatch()
        }
    }

    private fun formatTime(elapsedTime: Long): String {
        val hours = (elapsedTime / (1000 * 60 * 60)).toInt()
        val minutes = ((elapsedTime / (1000 * 60)) % 60).toInt()
        val seconds = ((elapsedTime / 1000) % 60).toInt()
        val milliseconds = (elapsedTime % 1000).toInt()

        return String.format(
            Locale.getDefault(),
            "%02d:%02d:%02d:%03d",
            hours, minutes, seconds, milliseconds
        )
    }

    private fun stopStopWatch() {
        isRunning = false
        handler.removeCallbacks(runnable)
        btnStartStop.text = "START"
        val lapTime = System.currentTimeMillis() - startTime
        lapTimes.add(lapTime)
        val lapTimeString = "Lap: $lapNumber : ${formatTime(lapTime)}"
        tvLapTime.text = "${tvLapTime.text}\n$lapTimeString"
    }

    fun resetWatch(view: View) {
        isRunning = false
        handler.removeCallbacks(runnable)
        tvTime.text = "00:00:00:00"
        btnStartStop.text = "START"
        lapNumber = 1
        lapTimes.clear()
        tvLapTime.text = ""
    }

    fun lapButton(view: View) {
        if (isRunning) {
            val lapTime = System.currentTimeMillis() - startTime
            lapTimes.add(lapTime)
            val lapTimeString = "Lap $lapNumber: ${formatTime(lapTime)}"
            tvLapTime.text = "${tvLapTime.text}\n$lapTimeString"
            lapNumber++

            val entry = Entry(lapNumber.toFloat(), lapTime.toFloat())

            val entries = ArrayList<Entry>()
            entries.add(entry)

            val lineDataSet = LineDataSet(entries, "Lap times")
            lineDataSet.setDrawIcons(false)
            lineDataSet.color = Color.RED
            lineDataSet.lineWidth = 3f
            lineDataSet.circleRadius = 5f
            lineDataSet.valueTextSize = 9f
            lineDataSet.setDrawValues(false)

            var lineData = chart.data
            if (lineData == null) {
                lineData = LineData(lineDataSet)
                chart.data = lineData
            } else {
                lineData.addDataSet(lineDataSet)
                chart.notifyDataSetChanged()
            }

            chart.setVisibleXRangeMaximum(5f)
            chart.moveViewToX(lapNumber.toFloat() - 5)
        }
    }

}