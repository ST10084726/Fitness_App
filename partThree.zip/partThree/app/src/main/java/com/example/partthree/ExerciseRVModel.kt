package com.example.partthree

class ExerciseRVModel (
    var exerciseName: String,
    var exerciseDescription: String,
    var imgUrl: String,
    var calories: Int,
    var time: Int
)