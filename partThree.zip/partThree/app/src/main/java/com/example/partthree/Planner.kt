package com.example.partthree

import android.app.AlertDialog
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.*
import com.google.firebase.database.*
import java.text.SimpleDateFormat
import java.util.*

class Planner : AppCompatActivity() {
    //variables
    private lateinit var spinner: Spinner
    private lateinit var saveButton: Button
    private lateinit var capButton: Button
    private lateinit var etName: EditText
    private lateinit var etDesc: EditText
    private lateinit var startDateButton: Button
    private lateinit var startTimeButton: Button
    private lateinit var endDateButton: Button
    private lateinit var endTimeButton: Button
    private lateinit var readButton: Button
    private lateinit var database: DatabaseReference
    private var startDate: Date? = null
    private var startTime: Date? = null
    private var endDate: Date? = null
    private var endTime: Date? = null
    private var alertDialog: AlertDialog? = null //ui to place data on

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_planner)
        etName = findViewById(R.id.edName)
        etDesc = findViewById(R.id.edDesc)
        spinner = findViewById(R.id.spinner)
        saveButton = findViewById(R.id.saveButton)
        capButton = findViewById(R.id.Capture)
        readButton = findViewById(R.id.Read)
        startDateButton = findViewById(R.id.startDateButton)
        startTimeButton = findViewById(R.id.startTimeButton)
        endDateButton = findViewById(R.id.endDateButton)
        endTimeButton = findViewById(R.id.endTimeButton)

        // Initialize Firebase Database
        database = FirebaseDatabase.getInstance().reference

        startDateButton.setOnClickListener { showDatePicker(startDateListener) }
        startTimeButton.setOnClickListener { showTimePicker(startTimeListener) }
        endDateButton.setOnClickListener { showDatePicker(endDateListener) }
        endTimeButton.setOnClickListener { showTimePicker(endTimeListener) }

        // Set up spinner adapter
        val spinnerAdapter = ArrayAdapter.createFromResource(
            this,
            R.array.spinner_items,
            android.R.layout.simple_spinner_dropdown_item
        )
        spinner.adapter = spinnerAdapter

        //
        saveButton.setOnClickListener {
            val selectedItem = spinner.selectedItem as String
            val taskName = etName.text.toString()
            val taskDesc = etDesc.text.toString()

            //optional
            if (taskName.isEmpty()) {
                etName.error = "Please enter a task name"
                return@setOnClickListener
            }
            if (taskDesc.isEmpty()) {
                etDesc.error = "Please enter a task desc"
                return@setOnClickListener
            }
            saveToFirebase(selectedItem, taskName, taskDesc)
        }
        capButton.setOnClickListener{
            val intent = Intent(this@Planner,Camera::class.java)
            startActivity(intent)
        }
        readButton.setOnClickListener {
            val startDate = startDate ?: return@setOnClickListener
            val endDate = endDate ?: return@setOnClickListener
            fetchEntriesFromFirebase(startDate, endDate)
        }
    }

    // methods for calendar and timer pickers
    private fun showDatePicker(dateSetListener: DatePickerDialog.OnDateSetListener) {
        val calendar = Calendar.getInstance()
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH)
        val day = calendar.get(Calendar.DAY_OF_MONTH)

        val datePickerDialog = DatePickerDialog(this, dateSetListener, year, month, day)
        datePickerDialog.show()
    }
    private fun showTimePicker(timeSetListener: TimePickerDialog.OnTimeSetListener) {
        val calendar = Calendar.getInstance()
        val hour = calendar.get(Calendar.HOUR_OF_DAY)
        val minute = calendar.get(Calendar.MINUTE)

        val timePickerDialog = TimePickerDialog(this, timeSetListener, hour, minute, true)
        timePickerDialog.show()
    }

    private val startDateListener =
        DatePickerDialog.OnDateSetListener { _: DatePicker, year: Int, month: Int, day: Int ->
            val selectedCalendar = Calendar.getInstance()
            selectedCalendar.set(year, month, day)
            startDate = selectedCalendar.time

            val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
            val selectedDateString = dateFormat.format(startDate!!)
            startDateButton.text = selectedDateString
        }

    private val startTimeListener =
        TimePickerDialog.OnTimeSetListener { _: TimePicker, hourOfDay: Int, minute: Int ->
            val selectedCalendar = Calendar.getInstance()
            selectedCalendar.time = startDate
            selectedCalendar.set(Calendar.HOUR_OF_DAY, hourOfDay)
            selectedCalendar.set(Calendar.MINUTE, minute)
            startTime = selectedCalendar.time

            val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())
            val selectedTimeString = timeFormat.format(startTime!!)
            startTimeButton.text = selectedTimeString
        }

    private val endDateListener =
        DatePickerDialog.OnDateSetListener { _: DatePicker, year: Int, month: Int, day: Int ->
            val selectedCalendar = Calendar.getInstance()
            selectedCalendar.set(year, month, day)
            endDate = selectedCalendar.time

            val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
            val selectedDateString = dateFormat.format(endDate!!)
            endDateButton.text = selectedDateString
        }

    private val endTimeListener =
        TimePickerDialog.OnTimeSetListener { _: TimePicker, hourOfDay: Int, minute: Int ->
            val selectedCalendar = Calendar.getInstance()
            selectedCalendar.time = endDate
            selectedCalendar.set(Calendar.HOUR_OF_DAY, hourOfDay)
            selectedCalendar.set(Calendar.MINUTE, minute)
            endTime = selectedCalendar.time

            val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())
            val selectedTimeString = timeFormat.format(endTime!!)
            endTimeButton.text = selectedTimeString
        }

    //save to firebase method
    private fun saveToFirebase(item: String, taskName: String?, taskDesc: String) {
        val dateFormat = SimpleDateFormat("yyyy-mm-dd", Locale.getDefault())
        val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())

        //for the 2 dates and 2 times
        val startDateString = startDateButton.text.toString()
        val startTimeString = startTimeButton.text.toString()
        val endDateString = endDateButton.text.toString()
        val endTimeString = endTimeButton.text.toString()

        //parsing the data
        val startDate = dateFormat.parse(startDateString)
        val startTime = timeFormat.parse(startTimeString)
        val endDate = dateFormat.parse(endDateString)
        val endTime = timeFormat.parse(endTimeString)

        //calcs ==> total time spent
        val totalTimeInMillis = endDate.time - startDate.time + endTime.time - startTime.time
        val totalMinutes = totalTimeInMillis / (1000 * 60)
        val totalHours = totalMinutes / 60
        val minutesRemaining = totalHours % 60

        //format to pass into the db
        val totalTimeString = String.format(
            Locale.getDefault(),
            "%02d:%02d", totalHours, minutesRemaining
        )

        //key value pair to pass into firebase
        val key = database.child("items").push().key
        if (key != null) {
            val task = TaskModel(
                taskName, taskDesc, startDateString,
                startTimeString, endDateString, endTimeString, totalTimeString
            )
            database.child("items").child(key).setValue(task)
                .addOnSuccessListener {
                    Toast.makeText(this, "Data saved to firebase", Toast.LENGTH_SHORT).show()
                }
                .addOnFailureListener {
                    Toast.makeText(this, "Error has occured", Toast.LENGTH_SHORT).show()
                }

        }
    }//end save to fb

    private fun fetchEntriesFromFirebase(startDate: Date, endDate: Date) {
        val query = database.child("items")
            .orderByChild("startDateString")
            .startAt(SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(startDate))
            .endAt(SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(endDate))

        query.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val entries: MutableList<TaskModel> = mutableListOf()
                for (entrySnapshot in snapshot.children) {
                    val entry = entrySnapshot.getValue(TaskModel::class.java)
                    entry?.let {
                        entries.add(it)
                    }
                }
                //add alert db -- and pass to it
                showEntriesAlert(entries)
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(this@Planner, "Failed to read entry", Toast.LENGTH_SHORT).show()
            }
        })
    }// fetch

    private fun showEntriesAlert(entries: List<TaskModel>) {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Timesheet Entries")
        if (entries.isEmpty()) {
            builder.setMessage("No entries found")
        } else {
            val entryText = entries.mapIndexed { index, entry ->
                "Entry ${index + 1}: \n"
                "Task Name: ${entry.taskName}: \n" +
                        "Task Desc: ${entry.taskDesc}: \n" +
                        "Start Date: ${entry.startDateString}: \n" +
                        "Start Time: ${entry.startTimeString}: \n" +
                        "End Date: ${entry.endDateString}: \n" +
                        "End Time: ${entry.endTimeString}: \n" +
                        "Total Time: ${entry.totalTimeString}: \n\n"
            }
            val entriesText = entryText.reduce { acc, entryText -> acc + entryText }

            builder.setMessage(entriesText)
        }//else ends
        //box buttons to close entry
        builder.setPositiveButton("OK") { dialog, _ ->
            dialog.dismiss() //closes the dialog box
        }
        alertDialog = builder.create()
        alertDialog?.show()
    }

}
// end class

// task model class
data class TaskModel(
    var taskName: String? = null,
    var taskDesc: String? = null,
    var startDateString: String? = null,
    var startTimeString: String? = null,
    var endDateString: String? = null,
    var endTimeString: String? = null,
    var totalTimeString: String?=null
)