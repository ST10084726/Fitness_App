package com.example.partthree

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.airbnb.lottie.LottieAnimationView

class ExerciseRVAdapter(
    private val exerciseRVModelArrayList: ArrayList<ExerciseRVModel>,
    private val context: Context,
    private val exerciseClickInterface: ExerciseClickInterface
) : RecyclerView.Adapter<ExerciseRVAdapter.ExerciseViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ExerciseViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.exercise_rv_item, parent, false)
        return ExerciseViewHolder(view)
    }

    override fun onBindViewHolder(holder: ExerciseViewHolder, position: Int) {
        val exerciseRVModel = exerciseRVModelArrayList[position]
        holder.exerciseTV.text = exerciseRVModel.exerciseName
        holder.exerciseLAV.setAnimationFromUrl(exerciseRVModel.imgUrl)
        val time = "${exerciseRVModel.time} MIN"
        holder.timeTV.text = time

        holder.itemView.setOnClickListener {
            exerciseClickInterface.onExerciseClick(position)
        }
    }

    override fun getItemCount(): Int {
        return exerciseRVModelArrayList.size
    }

    inner class ExerciseViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val exerciseTV: TextView = itemView.findViewById(R.id.idExerciseName)
        val timeTV: TextView = itemView.findViewById(R.id.idExerciseTime)
        val exerciseLAV: LottieAnimationView = itemView.findViewById(R.id.idExerciseLAV)
    }

    interface ExerciseClickInterface {
        fun onExerciseClick(position: Int)
    }
}
