package com.example.partthree

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import androidx.cardview.widget.CardView

class Home : AppCompatActivity() {
    // Variables
    private lateinit var cardExercise: CardView
    private lateinit var cardPlanner: CardView
    private lateinit var cardCamera: CardView
    private lateinit var cardAbout: CardView
    private lateinit var cardLogout: CardView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)
        cardExercise = findViewById(R.id.cardExercise)
        cardPlanner = findViewById(R.id.cardPlanner)
        cardCamera = findViewById(R.id.cardCamera)
        cardAbout = findViewById(R.id.cardAbout)
        cardLogout = findViewById(R.id.cardLogOut)

        cardExercise.setOnClickListener{
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }
        cardPlanner.setOnClickListener{
            val intent = Intent(this, Planner::class.java)
            startActivity(intent)
        }
        cardCamera.setOnClickListener{
            val intent = Intent(this, Camera::class.java)
            startActivity(intent)
        }
        cardAbout.setOnClickListener {
            val intent = Intent(this, About::class.java)
            startActivity(intent)
        }
        cardLogout.setOnClickListener{
            val intent = Intent(this, login::class.java)
            startActivity(intent)
        }



    }
}