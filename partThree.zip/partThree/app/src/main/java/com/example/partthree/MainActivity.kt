package com.example.partthree

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import com.airbnb.lottie.LottieAnimationView

class MainActivity : AppCompatActivity() {
    //variables
    private lateinit var exerciseLL: LinearLayout
    private lateinit var stepCounterLL: LinearLayout
    private lateinit var exerciseLAV: LottieAnimationView
    private lateinit var counterLAV: LottieAnimationView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        exerciseLL = findViewById(R.id.LLExercise)
        stepCounterLL = findViewById(R.id.LLStepCounter)
        exerciseLAV = findViewById(R.id.LAVExercise)
        counterLAV = findViewById(R.id.LAVStepCounter)

        // Set animations
        exerciseLAV.setAnimationFromUrl("https://assets7.lottiefiles.com/packages/lf20_vxnelydc.json")
        counterLAV.setAnimationFromUrl("https://assets7.lottiefiles.com/private_files/lf30_qvxyuniu.json")

        exerciseLL.setOnClickListener {
            val intent = Intent(this@MainActivity, Exercise::class.java)
            startActivity(intent)
        }

        stepCounterLL.setOnClickListener {
            val intent = Intent(this@MainActivity, Tracker::class.java)
            startActivity(intent)
        }


    }
}