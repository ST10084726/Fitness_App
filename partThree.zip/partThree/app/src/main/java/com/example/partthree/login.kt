package com.example.partthree

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth

class login : AppCompatActivity() {
    // Variables
    private lateinit var edUsername: EditText
    private lateinit var edPassword: EditText
    private lateinit var btnLogin: Button
    private lateinit var btnReg: Button
    private lateinit var mAuth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        mAuth = FirebaseAuth.getInstance()
        edUsername = findViewById(R.id.editTextTextEmailAddress)
        edPassword = findViewById(R.id.editTextTextPassword)
        btnLogin = findViewById(R.id.btnLogin)
        btnReg = findViewById(R.id.btnReg)

        btnLogin.setOnClickListener {
            loginUser()
        }

        btnReg.setOnClickListener {
            val intent = Intent(this, Register::class.java)
            startActivity(intent)
        }

    }

    private fun loginUser() {
        val email = edUsername.text.toString().trim()
        val password = edPassword.text.toString().trim()

        if (email.isEmpty()) {
            Toast.makeText(this, "Please enter an email address!", Toast.LENGTH_SHORT).show()
            edUsername.requestFocus()
            return
        }

        if (password.isEmpty()) {
            Toast.makeText(this, "Please enter a password!", Toast.LENGTH_SHORT).show()
            edPassword.requestFocus()
            return
        }

        mAuth.signInWithEmailAndPassword(email, password)
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    Toast.makeText(this, "Login Successful!", Toast.LENGTH_SHORT).show()
                    edUsername.setText("")
                    edPassword.setText("")
                    edUsername.requestFocus()
                    val intent = Intent(this, Home::class.java)
                    startActivity(intent)
                } else {
                    Toast.makeText(this, "Login Unsuccessful! Please try again.", Toast.LENGTH_SHORT).show()
                    edUsername.setText("")
                    edPassword.setText("")
                    edUsername.requestFocus()
                }
            }
            .addOnFailureListener { e ->
                Toast.makeText(this, "Error Occurred: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }

}