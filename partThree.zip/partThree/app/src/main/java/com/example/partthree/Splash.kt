package com.example.partthree

import android.content.Intent
import android.os.Bundle
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import java.util.*

class Splash : AppCompatActivity() {
    //variables
    var imgLogo: ImageView? = null
    var delay: Long = 5000 // splash timing

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)
        imgLogo = findViewById(R.id.imageView)

        //splash code
        // create a Timer obj

        //splash code
        // create a Timer obj
        val runSplash = Timer()
        //add the timer task obj
        //add the timer task obj
        val showSplash: TimerTask = object : TimerTask() {
            override fun run() {
                finish() //using the delay

                //move onto the next screen
                val intentSplash = Intent(this@Splash, login::class.java)
                startActivity(intentSplash)
            }
        }
        runSplash.schedule(showSplash, delay)
    }
}